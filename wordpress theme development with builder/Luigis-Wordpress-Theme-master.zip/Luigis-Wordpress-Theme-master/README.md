# Luigis Wordpress Theme
Converting form HTML to Wordpress Theme

##### Plugins used
  - Advanced Custom Fields Pro
  - Contact Form 7

##### Pages
  - Home page
  - About page
  - Contact page

##### Screenshots
![Screenshot](/screenshot.png "Screenshot")
