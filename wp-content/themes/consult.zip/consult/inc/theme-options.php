























<?php
// Legacy Update
function consult_visual_composer_legacy_update() {
    if ( defined( 'WPB_VC_VERSION' ) && version_compare( WPB_VC_VERSION, '4.3.5', '<' ) ) {
        do_action( 'vc_before_init' );
    }
}
add_action( 'admin_init', 'consult_visual_composer_legacy_update' );

/* Set Visual Composer */
// Removes tabs such as the "Design Options" from the Visual Composer Settings & page and disables automatic updates.
function consult_visual_composer_set_as_theme() {
    vc_set_as_theme( true );
}
add_action( 'vc_before_init', 'consult_visual_composer_set_as_theme' );
// Remove Default Shortcodes
if ( ! function_exists( 'consult_visual_composer_remove_default_shortcodes' ) ) {
    function consult_visual_composer_remove_default_shortcodes() {
        //vc_remove_element( 'vc_column_text' );
        //vc_remove_element( 'vc_separator' );
        //vc_remove_element( 'vc_text_separator' );
        //vc_remove_element( 'vc_message' );
        //vc_remove_element( 'vc_facebook' );
        //vc_remove_element( 'vc_tweetmeme' );
        //vc_remove_element( 'vc_googleplus' );
        vc_remove_element( 'vc_pinterest' );
        vc_remove_element( 'vc_toggle' );
        //vc_remove_element( 'vc_single_image' );
        vc_remove_element( 'vc_gallery' );
        vc_remove_element( 'vc_images_carousel' );
        vc_remove_element( 'vc_tabs' );
        vc_remove_element( 'vc_tour' );
        vc_remove_element( 'vc_accordion' );
        vc_remove_element( 'vc_posts_grid' );
        vc_remove_element( 'vc_carousel' );
        vc_remove_element( 'vc_posts_slider' );
        vc_remove_element( 'vc_widget_sidebar' );
        vc_remove_element( 'vc_button' );
        vc_remove_element( 'vc_cta_button' );
        //vc_remove_element( 'vc_video' );
        //vc_remove_element( 'vc_gmaps' );
        //vc_remove_element( 'vc_raw_html' );
        vc_remove_element( 'vc_raw_js' );
        vc_remove_element( 'vc_flickr' );
        //vc_remove_element( 'vc_progress_bar' );
        //vc_remove_element( 'vc_pie' );
        //vc_remove_element( 'contact-form-7' );
        vc_remove_element( 'rev_slider_vc' );
        vc_remove_element( 'rev_slider' );
        vc_remove_element( 'vc_wp_search' );
        vc_remove_element( 'vc_wp_meta' );
        vc_remove_element( 'vc_wp_recentcomments' );
        vc_remove_element( 'vc_wp_calendar' );
        vc_remove_element( 'vc_wp_pages' );
        vc_remove_element( 'vc_wp_tagcloud' );
        vc_remove_element( 'vc_wp_custommenu' );
        //vc_remove_element( 'vc_wp_text' );
        vc_remove_element( 'vc_wp_posts' );
        vc_remove_element( 'vc_wp_links' );
        vc_remove_element( 'vc_wp_categories' );
        vc_remove_element( 'vc_wp_archives' );
        vc_remove_element( 'vc_wp_rss' );
        vc_remove_element( 'vc_button2' );
        vc_remove_element( 'vc_cta_button2' );
        //vc_remove_element( 'vc_custom_heading' );
        //vc_remove_element( 'vc_empty_space' );
        //vc_remove_element( 'vc_icon' );
        vc_remove_element( 'vc_tta_tabs' );
        vc_remove_element( 'vc_tta_tour' );
        vc_remove_element( 'vc_tta_accordion' );
        vc_remove_element( 'vc_tta_pageable' );
        //vc_remove_element( 'vc_btn' );
        vc_remove_element( 'vc_cta' );
        vc_remove_element( 'vc_round_chart' );
        vc_remove_element( 'vc_line_chart' );
        vc_remove_element( 'vc_basic_grid' );
        //vc_remove_element( 'vc_media_grid' );
        vc_remove_element( 'vc_masonry_grid' );
        vc_remove_element( 'vc_acf' );
        //vc_remove_element( 'vc_masonry_media_grid' );
    }
    add_action( 'vc_before_init', 'consult_visual_composer_remove_default_shortcodes' );
}
// Remove Default Templates
if ( ! function_exists( 'consult_visual_composer_remove_default_templates' ) ) {
    function consult_visual_composer_remove_default_templates( $data ) {
        return array();
    }
    add_filter( 'vc_load_default_templates', 'consult_visual_composer_remove_default_templates' );
}
// Remove Meta Boxes
if ( ! function_exists( 'consult_visual_composer_remove_meta_boxes' ) ) {
    function consult_visual_composer_remove_meta_boxes() {
        if ( is_admin() ) {
            foreach ( get_post_types() as $post_type ) {
                remove_meta_box( 'vc_teaser',  $post_type, 'side' );
            }
        }
    }
    add_action( 'do_meta_boxes', 'consult_visual_composer_remove_meta_boxes' );
}
// Disable Frontend Editor
if ( function_exists( 'vc_disable_frontend' ) ) {
    vc_disable_frontend();
}
// Map Shortcodes
if ( ! function_exists( 'consult_visual_composer_map_shortcodes' ) ) {
    function consult_visual_composer_map_shortcodes() {
        $animations = array(
            'Select' => '',
            'bounce' => 'bounce',
            'bounceIn'     => 'bounceIn',
            'flash'     => 'flash',
            'pulse'     => 'pulse',
            'rubberBand'     => 'rubberBand',
            'shake'     => 'shake',
            'swing'     => 'swing',
            'tada'     => 'tada',
            'wobble'     => 'wobble',
            'jello'     => 'jello',
            'fadeIn'     => 'fadeIn',
            'fadeInDown'     => 'fadeInDown',
            'fadeInDownBig'     => 'fadeInDownBig',
            'fadeInLeft'     => 'fadeInLeft',
            'fadeInLeftBig'     => 'fadeInLeftBig',
            'fadeInRight'     => 'fadeInRight',
            'fadeInRightBig'     => 'fadeInRightBig',
            'fadeInUp'     => 'fadeInUp',
            'fadeInUpBig'     => 'fadeInUpBig',
            'fadeOut'     => 'fadeOut',
            'fadeOutDown'     => 'fadeOutDown',
            'fadeOutDownBig'     => 'fadeOutDownBig',
            'fadeOutLeft'     => 'fadeOutLeft',
            'fadeOutLeftBig'     => 'fadeOutLeftBig',
            'fadeOutRight'     => 'fadeOutRight',
            'fadeOutRightBig'     => 'fadeOutRightBig',
            'fadeOutUp'     => 'fadeOutUp',
            'fadeOutUpBig'     => 'fadeOutUpBig',
            'slideInUp'     => 'slideInUp',
            'slideInDown'     => 'slideInDown',
            'slideInLeft'     => 'slideInLeft',
            'slideInRight'     => 'slideInRight',
            'zoomIn'     => 'zoomIn',
            'zoomInDown'     => 'zoomInDown',
            'zoomInLeft'     => 'zoomInLeft',
            'zoomInRight'     => 'zoomInRight',
            'zoomInUp'     => 'zoomInUp',
        );
       //section 1 
  //section 1 
    vc_map(array(
    'name'=>__('First Section','text-donain'),
    'description'=>'This is First Addon',
    'base'=>'section_1_base',
    'category'=>'Consult',
    'icon'=> get_template_directory_uri().'/images/favicon.ico',
    'params'=>array(
    
       array(
       'param_name'=>'title_sec_1',
       'type'=>'textfield',
       'heading'=>'Section One Title ',
       'value'=>'Placeholder',

       ),
          
          
      array(
       'param_name'=>'title_sec_desc_1',
       'type'=>'textarea',
       'heading'=>'Section One Description ',
       'value'=>'Placeholder',

       ),
          
          
      array(
       'param_name'=>'title_sec_desc_1_color',
       'type'=>'colorpicker',
       'heading'=>'Section One Description color ',
       ),
       
       
      array(
       'param_name'=>'title_sec_1_image',
       'type'=>'attach_image',
       'heading'=>'Section One Image ',
       ),
       
    
    ),
    
   ));
    
    
 //section 3
 
 
 vc_map(array(
    'name'=>__('Third Section','text-donain'),
    'description'=>'This is Third Addon',
    'base'=>'section_2_base',
    'category'=>'Consult',
    'icon'=> get_template_directory_uri().'/images/favicon.ico',
    'params'=>array(
    
     array(
    
    'type'=>'param_group',
    'heading'=>'Section 3 Items',
    'param_name'=>'sec_3_grp',
    'params'=>array(
    
       array(
    
       'param_name'=>'icon_image',
       'heading'=>'Section 3 Dropdown',
       'type'=>'dropdown',
       'value'=>array(
         'Select a value'=>'',
         'Icon'=>'fontawesome',
         'Image'=>'custom',
       ),
    
    ),
   
    array(
       'param_name'=>'sec_3_icon',
       'heading'=>'Section 3 Icon',
       'type'=>'iconpicker',
      'dependency' => array(
             'element' => 'icon_image',
            'value' => 'fontawesome',
         ),
 
       ),         

    array(
       'param_name'=>'sec_3_image',
       'heading'=>'Section 3 Image',
       'type'=>'attach_image',
       'dependency'=>array(
         'element'=>'icon_image',
         'value'=>'custom',
       ),
       
    ),    
    
    array(
       'param_name'=>'sec_3_title',
       'heading'=>'Section 3 Title',
       'type'=>'textfield',
       'group'=>'Amit',
       
    ),    
    
    array(
       'param_name'=>'sec_3_desc',
       'heading'=>'Section 3 Description',
       'type'=>'textarea',
       'group'=>'Amit',
       
    ),
    
    
    )
    
    
    ),
    
    

 
    )

 ));
 





  //section 3
 
 
 vc_map(array(
    'name'=>__('Service Section','text-donain'),
    'description'=>'This is Fourth Addon',
    'base'=>'section_6_base',
    'category'=>'Consult',
    'icon'=> get_template_directory_uri().'/images/favicon.ico',
    'params'=>array(
    
     array(
    
    'type'=>'param_group',
    'heading'=>'Section 3 Items',
    'param_name'=>'sec_3_grp1',
    'params'=>array(
    
       array(
    
       'param_name'=>'icon_image1',
       'heading'=>'Section 3 Dropdown',
       'type'=>'dropdown',
       'value'=>array(
         'Select a value'=>'',
         'Icon'=>'fontawesome',
         'Image'=>'custom',
       ),
    
    ),
   
    array(
       'param_name'=>'sec_3_icon1',
       'heading'=>'Section 3 Icon',
       'type'=>'iconpicker',
      'dependency' => array(
             'element' => 'icon_image',
            'value' => 'fontawesome',
         ),
 
       ),         

    array(
       'param_name'=>'sec_3_image1',
       'heading'=>'Section 3 Image',
       'type'=>'attach_image',
       'dependency'=>array(
         'element'=>'icon_image',
         'value'=>'custom',
       ),
       
    ),    
    
    array(
       'param_name'=>'sec_3_title1',
       'heading'=>'Section 3 Title',
       'type'=>'textfield',
       'group'=>'Amit',
       
    ),    
    
    array(
       'param_name'=>'sec_3_desc1',
       'heading'=>'Section 3 Description',
       'type'=>'textarea',
       'group'=>'Amit',
       
    ),
    
    
    )
    
    
    ),
    
    

 
    )

 ));
 //Blog Options
 
 vc_map(array(
 'name'=>'Blog Section',
 'description'=>'This is Blog',
 'base'=>'section_4_blog',
 'category'=>'Consult',
 'icon'=> get_template_directory_uri().'/images/favicon.ico',
 'params'=>array(
 
     array(
    'param_name'=>'sec_blog_title',
    'heading'=>'Latest Title',
    'type'=>'textfield', 
    ),
    array(
                    "type" => "textfield",
                    "heading" => "Number of Posts",
                    "param_name" => "number_of_posts",
                    "admin_label" => true,
                    "holder" => "div",
                    "class" => "",
                    "value" => ''
                ),

       // Display Order
                    array(
                        'param_name'  => 'order',
                        'heading'     => esc_html__( 'Display Order', 'consult-wp' ),
                        'description' => esc_html__( 'Set posts display order.', 'consult-wp' ),
                        'type'        => 'dropdown',
                        'value'       => array(
                            'Select' => '',
                            'Ascending' => 'ASC',
                            'Descending'     => 'DESC'
                        ),
                        "admin_label"  => true
                    ),
                    // Category Slug
                    array(
                        'param_name'  => 'cat_slug',
                        'heading'     => esc_html__( 'Category Slug', 'consult-wp' ),
                        'description' => esc_html__( 'Enter category slug or leave empty for all.', 'consult-wp' ),
                        'type'        => 'textfield',
                        "admin_label"  => true
                    ),

   )
 
 ));
 
 


 vc_map(array(
 'name'=>'Portfolio Section',
 'description'=>'This is Portfolio',
 'base'=>'section_5_portfolio',
 'category'=>'Consult',
 'icon'=> get_template_directory_uri().'/images/favicon.ico',
 'params'=>array(
 
     array(
    'param_name'=>'sec_portfolio_post_per_page',
    'heading'=>'Post Per Page',
    'type'=>'textfield', 
    )

   )
 
 ));
  
 vc_map(array(
 'name'=>'Contact Form 7 Section',
 'description'=>'This is Contact Form 7',
 'base'=>'section_cf',
 'category'=>'Consult',
 'icon'=> get_template_directory_uri().'/images/favicon.ico',
 'params'=>array(
 
     array(
    'param_name'=>'content',
    'heading'=>'Contact Form 7',
    'type'=>'textarea_html', 
    )
 )
 
 ));
    }
    add_action( 'vc_before_init', 'consult_visual_composer_map_shortcodes' );
    // Extend container class (parents).
    if(class_exists('WPBakeryShortCodesContainer')){
        class WPBakeryShortCode_Container extends WPBakeryShortCodesContainer { }

    }
    // Extend shortcode class (children).
    if(class_exists('WPBakeryShortCode')){
        class WPBakeryShortCode_section_1_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_2_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_3_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_4_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_5_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_6_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_7_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_8_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_9_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_10_base extends WPBakeryShortCode { }
        class WPBakeryShortCode_section_11_base extends WPBakeryShortCode { }
    }

}

// Update Existing Elements
if ( ! function_exists( 'consult_visual_composer_update_existing_shortcodes' ) ) {
    function consult_visual_composer_update_existing_shortcodes() {
    }
    add_action( 'admin_init', 'consult_visual_composer_update_existing_shortcodes' );
}
// Incremental ID Counter for Templates
if ( ! function_exists( 'consult_visual_composer_templates_id_increment' ) ) {
    function consult_visual_composer_templates_id_increment() {
        static $count = 0; $count++;
        return $count;
    }
}